"""CLI entrypoints for BOL-CD."""

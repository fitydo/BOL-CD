"""FastAPI app exposing BOL-CD endpoints."""

"""Connectors for SIEMs and Sigma conversion stubs."""
